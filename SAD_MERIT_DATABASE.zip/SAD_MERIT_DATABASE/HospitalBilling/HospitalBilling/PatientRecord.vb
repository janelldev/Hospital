﻿Public Class PatientRecord
    Private Sub Employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class