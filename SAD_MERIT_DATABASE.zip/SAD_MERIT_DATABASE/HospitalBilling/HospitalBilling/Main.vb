﻿Public Class Main
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        NewPatient.Show()
    End Sub

    Private Sub btnPatient_Click(sender As Object, e As EventArgs) Handles btnPatient.Click
        PatientRecord.Show()
    End Sub

    Private Sub btnEmployee_Click(sender As Object, e As EventArgs) Handles btnEmployee.Click
        Employee.Show()
    End Sub

    Private Sub btnRoom_Click(sender As Object, e As EventArgs) Handles btnRoom.Click
        Room.Show()
    End Sub
End Class