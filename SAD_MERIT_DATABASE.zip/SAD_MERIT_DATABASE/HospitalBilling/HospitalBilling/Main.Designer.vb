﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnPatient = New System.Windows.Forms.Button()
        Me.btnEmployee = New System.Windows.Forms.Button()
        Me.btnRoom = New System.Windows.Forms.Button()
        Me.btnBill = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnNew
        '
        Me.btnNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNew.Location = New System.Drawing.Point(12, 45)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(206, 54)
        Me.btnNew.TabIndex = 0
        Me.btnNew.Text = "&New Patient"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'btnPatient
        '
        Me.btnPatient.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPatient.Location = New System.Drawing.Point(12, 116)
        Me.btnPatient.Name = "btnPatient"
        Me.btnPatient.Size = New System.Drawing.Size(206, 54)
        Me.btnPatient.TabIndex = 1
        Me.btnPatient.Text = "&Patient Record"
        Me.btnPatient.UseVisualStyleBackColor = True
        '
        'btnEmployee
        '
        Me.btnEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEmployee.Location = New System.Drawing.Point(12, 190)
        Me.btnEmployee.Name = "btnEmployee"
        Me.btnEmployee.Size = New System.Drawing.Size(206, 54)
        Me.btnEmployee.TabIndex = 2
        Me.btnEmployee.Text = "&Employee"
        Me.btnEmployee.UseVisualStyleBackColor = True
        '
        'btnRoom
        '
        Me.btnRoom.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoom.Location = New System.Drawing.Point(12, 262)
        Me.btnRoom.Name = "btnRoom"
        Me.btnRoom.Size = New System.Drawing.Size(205, 54)
        Me.btnRoom.TabIndex = 3
        Me.btnRoom.Text = "&Room Admission"
        Me.btnRoom.UseVisualStyleBackColor = True
        '
        'btnBill
        '
        Me.btnBill.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBill.Location = New System.Drawing.Point(12, 331)
        Me.btnBill.Name = "btnBill"
        Me.btnBill.Size = New System.Drawing.Size(205, 54)
        Me.btnBill.TabIndex = 4
        Me.btnBill.Text = "&Billing"
        Me.btnBill.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.ClientSize = New System.Drawing.Size(239, 407)
        Me.Controls.Add(Me.btnBill)
        Me.Controls.Add(Me.btnRoom)
        Me.Controls.Add(Me.btnEmployee)
        Me.Controls.Add(Me.btnPatient)
        Me.Controls.Add(Me.btnNew)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Main"
        Me.Text = "Main"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnNew As Button
    Friend WithEvents btnPatient As Button
    Friend WithEvents btnEmployee As Button
    Friend WithEvents btnRoom As Button
    Friend WithEvents btnBill As Button
End Class
