﻿Public Class Login
    Dim con As New OleDb.OleDbConnection
    Dim dbProvider As String
    Dim dbSource As String
    Dim ds As New DataSet
    Dim da As OleDb.OleDbDataAdapter
    Dim sql As String
    Dim inc As Integer
    Dim maxRows As Integer
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;"
        dbSource = "Data Source=C:\Users\janell\Desktop\SAD_MERIT_DATABASE\Login.accdb"
        con.ConnectionString = dbProvider & dbSource
        con.Open()
        sql = "SELECT * FROM LOGIN_TABLE"
        da = New OleDb.OleDbDataAdapter(sql, con)
        da.Fill(ds, "LOGIN_TABLE")
        con.Close()
        maxRows = ds.Tables("LOGIN_TABLE").Rows.Count
        inc = -1

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim uname As String = ""
        Dim pword As String
        Dim username As String = ""
        Dim pass As String

        If txtUser.Text = "" Or txtPass.Text = "" Then
            MsgBox("Please, fill up the required fields", MsgBoxStyle.Information)
            txtUser.Focus()

        Else
            uname = txtUser.Text
            pword = txtPass.Text
            dbSource = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\janell\Desktop\SAD_MERIT_DATABASE\Login.accdb"
            sql = "SELECT Password FROM LOGIN_TABLE where Username= '" & uname & "';"
            Dim conn = New OleDb.OleDbConnection(dbSource)
            Dim cmd As New OleDb.OleDbCommand(Sql, conn)
            conn.Open()

            Try
                pass = cmd.ExecuteScalar().ToString
            Catch ex As Exception
                MsgBox("Username does not exist.", MsgBoxStyle.Information)
            End Try
            If (pword = pass) Then
                MsgBox("Successfully Logged In!", MsgBoxStyle.Information)
                Main.Show()
                If (Main.Visible) Then
                    Me.Close()
                End If
            Else
                MsgBox("Login Failed!", MsgBoxStyle.Information)
                txtUser.Clear()
                txtPass.Clear()
                txtUser.Focus()
            End If
        End If
    End Sub
End Class