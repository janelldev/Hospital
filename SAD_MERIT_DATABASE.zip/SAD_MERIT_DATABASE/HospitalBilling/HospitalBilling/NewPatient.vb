﻿Public Class NewPatient
    Dim con As New OleDb.OleDbConnection
    Dim dbProvider As String
    Dim dbSource As String
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim da As New OleDb.OleDbDataAdapter
    Dim sql As String
    Dim inc As Integer
    Dim maxRows As Integer
    Dim first As String
    Dim middle As String
    Dim last As String
    Dim address As String
    Dim number As String
    Dim occupation As String
    Dim birthday As String
    Dim age As String
    Dim sex As String
    Private Sub NewPatient_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbProvider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\janell\Desktop\SAD_MERIT_DATABASE\ServicesDatabase.accdb"
        con.ConnectionString = dbProvider
        con.Open()

        con.Close()
    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)
        Dim dsNewRow As DataRow

        dsNewRow = ds.Tables("PATIENT_TABLE").NewRow()
        dsNewRow.Item("PatientNumber") = txtPatient.Text
        dsNewRow.Item("FirstName") = txtFirst.Text
        dsNewRow.Item("MiddleName") = txtMiddle.Text
        dsNewRow.Item("LastName") = txtLast.Text
        dsNewRow.Item("Address") = txtAddress.Text
        dsNewRow.Item("ContactNumber") = txtContact.Text
        dsNewRow.Item("Occupation") = txtOccupation.Text
        dsNewRow.Item("Birthday") = txtBirthday.Text
        dsNewRow.Item("Age") = txtAge.Text
        dsNewRow.Item("Sex") = txtSex.Text
        dsNewRow.Item("Remarks") = txtRemarks.Text

        ds.Tables("PATIENT_TABLE").Rows.Add(dsNewRow)
        da.Update(ds, "PATIENT_TABLE")

        MsgBox("ADDED.")
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)

        ds.Tables("PATIENT_TABLE").Rows(inc).Item(1) = txtFirst.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(2) = txtMiddle.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(3) = txtLast.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(4) = txtAddress.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(5) = txtContact.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(6) = txtAge.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(7) = txtBirthday.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(8) = txtOccupation.Text
        ds.Tables("PATIENT_TABLE").Rows(inc).Item(9) = txtRemarks.Text

        da.Update(ds, "PATIENT_TABLE")
        MsgBox("DATA UPDATED.")
    End Sub
End Class
